package com.secure1xbot.services;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.secure1xbot.MainActivity;
import com.secure1xbot.network.PacketAnalyzer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * خدمة VPN الذكية المخصصة لاعتراض وتحليل حركة مرور اللعبة.
 * تعتمد على VpnService المدمجة في أندرويد.
 */
public class SmartVpnService extends VpnService {
    private static final String TAG = "SmartVpnService";
    private ParcelFileDescriptor vpnInterface = null;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private PacketAnalyzer packetAnalyzer = new PacketAnalyzer();

    // معلومات النفق الافتراضي
    private static final String VPN_ADDRESS = "10.0.0.2"; // عنوان IP المحلي للـ VPN
    private static final String VPN_ROUTE = "0.0.0.0"; // توجيه كل حركة المرور عبر الـ VPN

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "stop".equals(intent.getAction())) {
            disconnect();
            return START_NOT_STICKY;
        }

        // التحقق من الإذن
        if (vpnInterface == null) {
            connect();
        }
        return START_STICKY;
    }

    private void connect() {
        Log.d(TAG, "بدء اتصال VPN...");
        
        // 1. إعداد واجهة VPN
        Builder builder = new Builder();
        builder.addAddress(VPN_ADDRESS, 32);
        builder.addRoute(VPN_ROUTE, 0);
        
        // السماح للتطبيق بالوصول إلى الشبكة دون المرور عبر VPN (مهم لعمليات المزامنة والويب سوكيت)
        // يجب أن يتم استثناء التطبيق الذي نريد مراقبته إذا كان هو نفسه التطبيق الحالي
        // لكن في هذا السيناريو، نحن نريد اعتراض حركة المرور الخاصة بالتطبيق نفسه (اللعبة)
        // لذا سنسمح لجميع التطبيقات بالمرور عبر النفق الافتراضي
        
        // تعيين إشعار مستمر
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        builder.setSession("SmartVpnService");
        builder.setConfigureIntent(pendingIntent);

        try {
            // إنشاء الواجهة الافتراضية
            vpnInterface = builder.establish();
            if (vpnInterface != null) {
                Log.d(TAG, "تم إنشاء واجهة VPN بنجاح.");
                // 2. بدء معالجة الحزم
                startPacketProcessing();
            } else {
                Log.e(TAG, "فشل إنشاء واجهة VPN.");
            }
        } catch (Exception e) {
            Log.e(TAG, "خطأ أثناء إنشاء VPN: " + e.getMessage());
            disconnect();
        }
    }

    private void disconnect() {
        Log.d(TAG, "إيقاف خدمة VPN...");
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
                vpnInterface = null;
            } catch (IOException e) {
                Log.e(TAG, "خطأ أثناء إغلاق واجهة VPN: " + e.getMessage());
            }
        }
        stopSelf();
    }

    private void startPacketProcessing() {
        if (vpnInterface == null) return;

        final FileInputStream inputStream = new FileInputStream(vpnInterface.getFileDescriptor());
        final FileOutputStream outputStream = new FileOutputStream(vpnInterface.getFileDescriptor());
        final ByteBuffer packet = ByteBuffer.allocate(32767); // حجم الحزمة الأقصى

        executor.execute(() -> {
            try {
                while (vpnInterface != null) {
                    // قراءة الحزمة من النفق الافتراضي
                    int length = inputStream.read(packet.array());
                    if (length > 0) {
                        // 1. تحليل الحزمة باستخدام PacketAnalyzer
                        packetAnalyzer.analyze(packet, length);
                        
                        // 2. إعادة توجيه الحزمة لضمان استمرار الاتصال
                        packet.limit(length);
                        outputStream.write(packet.array(), 0, length);
                        packet.clear();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "خطأ في معالجة الحزم: " + e.getMessage());
            } finally {
                disconnect();
            }
        });
    }

    @Override
    public void onRevoke() {
        Log.d(TAG, "تم إلغاء إذن VPN.");
        disconnect();
    }

    @Override
    public void onDestroy() {
        disconnect();
        super.onDestroy();
    }
}
