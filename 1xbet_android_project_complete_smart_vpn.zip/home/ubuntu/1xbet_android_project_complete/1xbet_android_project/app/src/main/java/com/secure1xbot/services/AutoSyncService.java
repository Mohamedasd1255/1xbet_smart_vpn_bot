package com.secure1xbot.services;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.data.CrashRound;
import com.secure1xbot.data.LiveDataCollectionSystem;
import com.secure1xbot.sync.DataSyncManager;

import java.util.Timer;
import java.util.TimerTask;

/**
 * خدمة المزامنة التلقائية
 * تقوم بمزامنة البيانات مع الخادم بشكل دوري
 */
public class AutoSyncService extends Service {
    private static final String TAG = "AutoSyncService";
    
    private Timer syncTimer;
    private Handler handler;
    private int syncInterval; // بالدقائق
    
    private static boolean isRunning = false;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "خدمة المزامنة التلقائية تم إنشاؤها");
        
        handler = new Handler();
        syncInterval = 30; // افتراضي: 30 دقيقة
        
        isRunning = true;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "خدمة المزامنة التلقائية تم بدء تشغيلها");
        
        // استرداد فترة المزامنة من الإعدادات إذا كانت متوفرة
        if (intent != null && intent.hasExtra("sync_interval")) {
            syncInterval = intent.getIntExtra("sync_interval", 30);
        }
        
        // بدء مؤقت المزامنة
        startSyncTimer();
        
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "خدمة المزامنة التلقائية تم تدميرها");
        
        // إيقاف مؤقت المزامنة
        if (syncTimer != null) {
            syncTimer.cancel();
            syncTimer = null;
        }
        
        isRunning = false;
    }
    
    /**
     * بدء مؤقت المزامنة
     */
    private void startSyncTimer() {
        // إيقاف المؤقت الحالي إذا كان موجوداً
        if (syncTimer != null) {
            syncTimer.cancel();
        }
        
        // إنشاء مؤقت جديد
        syncTimer = new Timer();
        
        // تحويل الدقائق إلى مللي ثانية
        long intervalMillis = syncInterval * 60 * 1000;
        
        // جدولة مهمة المزامنة
        syncTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                performSync();
            }
        }, intervalMillis, intervalMillis);
        
        Log.d(TAG, "تم بدء مؤقت المزامنة: كل " + syncInterval + " دقيقة");
    }
    
    /**
     * تنفيذ المزامنة
     */
    private void performSync() {
        Log.d(TAG, "بدء عملية المزامنة التلقائية");
        
        // الحصول على مدير المزامنة
        DataSyncManager syncManager = CrashBotApplication.getInstance().getDataSyncManager();
        
        // تنفيذ المزامنة
        syncManager.syncNow(success -> {
            if (success) {
                Log.d(TAG, "تمت المزامنة التلقائية بنجاح");
            } else {
                Log.e(TAG, "فشلت المزامنة التلقائية");
            }
        });
    }
    
    /**
     * تحديث فترة المزامنة
     */
    public static void updateSyncInterval(int minutes) {
        if (isRunning) {
            Intent intent = new Intent(CrashBotApplication.getInstance(), AutoSyncService.class);
            intent.putExtra("sync_interval", minutes);
            CrashBotApplication.getInstance().startService(intent);
        }
    }
    
    /**
     * التحقق مما إذا كانت الخدمة قيد التشغيل
     */
    public static boolean isRunning() {
        return isRunning;
    }
}
