package com.secure1xbot.ai;

/**
 * نتيجة التنبؤ
 * تحتوي على القيمة المتنبأ بها ومستوى الثقة ومصدر التنبؤ
 */
public class PredictionResult {
    private float predictedValue;
    private float confidence;
    private String source;
    
    /**
     * إنشاء نتيجة تنبؤ جديدة
     * 
     * @param predictedValue القيمة المتنبأ بها
     * @param confidence مستوى الثقة (0.0 - 1.0)
     * @param source مصدر التنبؤ (main, simple, hybrid)
     */
    public PredictionResult(float predictedValue, float confidence, String source) {
        this.predictedValue = predictedValue;
        this.confidence = confidence;
        this.source = source;
    }
    
    /**
     * الحصول على القيمة المتنبأ بها
     * 
     * @return القيمة المتنبأ بها
     */
    public float getPredictedValue() {
        return predictedValue;
    }
    
    /**
     * تعيين القيمة المتنبأ بها
     * 
     * @param predictedValue القيمة المتنبأ بها
     */
    public void setPredictedValue(float predictedValue) {
        this.predictedValue = predictedValue;
    }
    
    /**
     * الحصول على مستوى الثقة
     * 
     * @return مستوى الثقة (0.0 - 1.0)
     */
    public float getConfidence() {
        return confidence;
    }
    
    /**
     * تعيين مستوى الثقة
     * 
     * @param confidence مستوى الثقة (0.0 - 1.0)
     */
    public void setConfidence(float confidence) {
        this.confidence = confidence;
    }
    
    /**
     * الحصول على مصدر التنبؤ
     * 
     * @return مصدر التنبؤ (main, simple, hybrid)
     */
    public String getSource() {
        return source;
    }
    
    /**
     * تعيين مصدر التنبؤ
     * 
     * @param source مصدر التنبؤ (main, simple, hybrid)
     */
    public void setSource(String source) {
        this.source = source;
    }
    
    /**
     * الحصول على مستوى المخاطرة
     * 
     * @return مستوى المخاطرة (SAFE, CAUTION, RISK)
     */
    public RiskLevel getRiskLevel() {
        if (predictedValue < 1.5f) {
            return RiskLevel.RISK;
        } else if (predictedValue < 2.0f) {
            return RiskLevel.CAUTION;
        } else {
            return RiskLevel.SAFE;
        }
    }
    
    /**
     * الحصول على توصية الرهان
     * 
     * @return توصية الرهان (PLAY_NOW, AVOID_NOW)
     */
    public BetAdvice getBetAdvice() {
        if (confidence < 0.5f) {
            return BetAdvice.UNCERTAIN;
        } else if (getRiskLevel() == RiskLevel.SAFE) {
            return BetAdvice.PLAY_NOW;
        } else {
            return BetAdvice.AVOID_NOW;
        }
    }
    
    @Override
    public String toString() {
        return "PredictionResult{" +
                "predictedValue=" + predictedValue +
                ", confidence=" + confidence +
                ", source='" + source + '\'' +
                ", riskLevel=" + getRiskLevel() +
                ", betAdvice=" + getBetAdvice() +
                '}';
    }
    
    /**
     * مستويات المخاطرة
     */
    public enum RiskLevel {
        SAFE,
        CAUTION,
        RISK
    }
    
    /**
     * توصيات الرهان
     */
    public enum BetAdvice {
        PLAY_NOW,
        AVOID_NOW,
        UNCERTAIN
    }
}
