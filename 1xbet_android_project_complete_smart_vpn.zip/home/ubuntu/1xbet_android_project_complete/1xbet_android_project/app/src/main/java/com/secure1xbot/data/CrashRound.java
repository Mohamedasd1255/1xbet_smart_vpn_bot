package com.secure1xbot.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

/**
 * كائن يمثل جولة لعبة Crash
 */
@Entity(tableName = "crash_rounds")
public class CrashRound implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @PrimaryKey(autoGenerate = true)
    private int id;
    private long timestamp;
    private float multiplier;
    private long roundId;
    
    /**
     * إنشاء جولة جديدة
     * 
     * @param timestamp وقت الجولة
     * @param multiplier المضاعف النهائي للجولة
     */
    public CrashRound(long timestamp, float multiplier) {
        this.timestamp = timestamp;
        this.multiplier = multiplier;
        this.roundId = timestamp; // استخدام الوقت كمعرف مؤقت للجولة
    }

    public CrashRound(int id, long timestamp, float multiplier, long roundId) {
        this.id = id;
        this.timestamp = timestamp;
        this.multiplier = multiplier;
        this.roundId = roundId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
        this.timestamp = timestamp;
        this.multiplier = multiplier;
        this.roundId = timestamp; // استخدام الوقت كمعرف مؤقت للجولة
    }
    
    /**
     * إنشاء جولة جديدة مع معرف محدد
     * 
     * @param timestamp وقت الجولة
     * @param multiplier المضاعف النهائي للجولة
     * @param roundId معرف الجولة
     */
    public CrashRound(long timestamp, float multiplier, long roundId) {
        this.timestamp = timestamp;
        this.multiplier = multiplier;
        this.roundId = roundId;
    }
    
    /**
     * الحصول على وقت الجولة
     * 
     * @return وقت الجولة
     */
    public long getTimestamp() {
        return timestamp;
    }
    
    /**
     * تعيين وقت الجولة
     * 
     * @param timestamp وقت الجولة
     */
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    /**
     * الحصول على المضاعف النهائي للجولة
     * 
     * @return المضاعف النهائي للجولة
     */
    public float getMultiplier() {
        return multiplier;
    }
    
    /**
     * تعيين المضاعف النهائي للجولة
     * 
     * @param multiplier المضاعف النهائي للجولة
     */
    public void setMultiplier(float multiplier) {
        this.multiplier = multiplier;
    }
    
    /**
     * الحصول على معرف الجولة
     * 
     * @return معرف الجولة
     */
    public long getRoundId() {
        return roundId;
    }
    
    /**
     * تعيين معرف الجولة
     * 
     * @param roundId معرف الجولة
     */
    public void setRoundId(long roundId) {
        this.roundId = roundId;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CrashRound that = (CrashRound) obj;
        return id == that.id &&
               timestamp == that.timestamp &&
               Float.compare(that.multiplier, multiplier) == 0 &&
               roundId == that.roundId;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (int) (timestamp ^ (timestamp >>> 32));
        result = 31 * result + Float.floatToIntBits(multiplier);
        result = 31 * result + (int) (roundId ^ (roundId >>> 32));
        return result;
    }
    
    @Override
    public String toString() {
        return "CrashRound{" +
                "timestamp=" + timestamp +
                ", multiplier=" + multiplier +
                ", roundId=" + roundId +
                '}';
    }
}
