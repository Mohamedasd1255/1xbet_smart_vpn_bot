package com.secure1xbot.network;

import android.util.Log;
import com.secure1xbot.ai.PredictionResult;
import com.secure1xbot.CrashBotApplication;
import com.google.gson.Gson;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

import java.util.concurrent.TimeUnit;

/**
 * مرسل WebSocket مخصص لإرسال نتائج التنبؤات إلى المساعد الثاني (الخادم).
 * يستخدم OkHttp لإنشاء اتصال WebSocket عالي الأداء.
 */
public class WebSocketSender {
    private static final String TAG = "WebSocketSender";
    private static final String SERVER_URL = "ws://your-second-assistant-server.com/ws/predictions"; // يجب تعديل هذا
    
    private WebSocket webSocket;
    private OkHttpClient client;
    private Gson gson;

    public WebSocketSender() {
        this.gson = new Gson();
        this.client = new OkHttpClient.Builder()
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .pingInterval(30, TimeUnit.SECONDS)
                .build();
        
        connect();
    }

    private void connect() {
        Request request = new Request.Builder()
                .url(SERVER_URL)
                .build();
        
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                Log.i(TAG, "تم فتح اتصال WebSocket بنجاح.");
                // إرسال رسالة تعريفية
                webSocket.send("{\"type\": \"client_id\", \"id\": \"" + CrashBotApplication.getDeviceId() + "\"}");
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                Log.d(TAG, "رسالة مستلمة: " + text);
                // يمكن إضافة منطق لاستقبال الأوامر من المساعد الثاني هنا
            }

            @Override
            public void onMessage(WebSocket webSocket, ByteString bytes) {
                Log.d(TAG, "رسالة ثنائية مستلمة: " + bytes.hex());
            }

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                Log.w(TAG, "إغلاق الاتصال: " + code + " / " + reason);
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                Log.w(TAG, "تم إغلاق الاتصال: " + code + " / " + reason);
                // محاولة إعادة الاتصال بعد فترة
                reconnect();
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                Log.e(TAG, "فشل الاتصال: " + t.getMessage());
                // محاولة إعادة الاتصال بعد فترة
                reconnect();
            }
        });
    }
    
    private void reconnect() {
        try {
            Thread.sleep(5000); // الانتظار 5 ثوانٍ قبل المحاولة
            connect();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * إرسال نتيجة التنبؤ إلى المساعد الثاني.
     * 
     * @param result نتيجة التنبؤ من HybridAISystem
     */
    public void sendPrediction(PredictionResult result) {
        if (webSocket != null) {
            String json = gson.toJson(result);
            webSocket.send(json);
            Log.d(TAG, "تم إرسال التنبؤ: " + json);
        } else {
            Log.e(TAG, "فشل إرسال التنبؤ: الاتصال غير مفتوح.");
        }
    }

    public void close() {
        if (webSocket != null) {
            webSocket.close(1000, "Client closing");
        }
        client.dispatcher().executorService().shutdown();
    }
}
