package com.secure1xbot.network;

import android.util.Log;
import com.secure1xbot.ai.HybridAISystem;
import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.data.CrashRound;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.nio.ByteBuffer;

/**
 * محلل حزم البيانات (Packet Analyzer)
 * مسؤول عن تحليل حزم IP و TCP/UDP التي تمر عبر نفق VPN.
 */
public class PacketAnalyzer {
    private final HybridAISystem aiSystem;
    private final Gson gson;

    public PacketAnalyzer() {
        this.aiSystem = CrashBotApplication.getHybridAISystem();
        this.gson = new Gson();
    }
    private static final String TAG = "PacketAnalyzer";

    // بروتوكولات IP
    private static final int IP_PROTOCOL_TCP = 6;
    private static final int IP_PROTOCOL_UDP = 17;

    /**
     * تحليل حزمة IP
     * 
     * @param packet الحزمة في شكل ByteBuffer
     * @param length طول الحزمة
     */
    public void analyze(ByteBuffer packet, int length) {
        // يجب أن تكون الحزمة جاهزة للقراءة
        packet.limit(length);
        packet.position(0);

        // 1. تحليل رأس IP
        if (length < 20) { // الحد الأدنى لحجم رأس IP هو 20 بايت
            Log.w(TAG, "حزمة IP قصيرة جداً: " + length);
            return;
        }

        // قراءة الإصدار وطول رأس IP (IHL)
        byte versionAndIHL = packet.get();
        int version = (versionAndIHL >> 4) & 0x0F;
        int ipHeaderLength = (versionAndIHL & 0x0F) * 4;

        if (version != 4) { // نحن ندعم IPv4 فقط
            Log.d(TAG, "إصدار IP غير مدعوم: " + version);
            return;
        }

        if (length < ipHeaderLength) {
            Log.w(TAG, "حزمة IP غير مكتملة: " + length + " < " + ipHeaderLength);
            return;
        }

        // تخطي حقول TOS و Total Length
        packet.getShort(); // TOS
        int totalLength = packet.getShort(); // Total Length

        // تخطي حقول Identification و Flags/Fragment Offset و TTL
        packet.getInt(); // Identification + Flags/Fragment Offset
        packet.get(); // TTL

        // قراءة حقل البروتوكول
        int protocol = packet.get() & 0xFF;

        // تخطي حقل Checksum
        packet.getShort(); // Checksum

        // قراءة عناوين IP المصدر والوجهة
        int sourceIp = packet.getInt();
        int destinationIp = packet.getInt();

        // 2. تحليل رأس البروتوكول التالي
        int payloadLength = length - ipHeaderLength;
        
        if (protocol == IP_PROTOCOL_TCP) {
            analyzeTcpPacket(packet, ipHeaderLength, payloadLength, sourceIp, destinationIp);
        } else if (protocol == IP_PROTOCOL_UDP) {
            analyzeUdpPacket(packet, ipHeaderLength, payloadLength, sourceIp, destinationIp);
        } else {
            Log.d(TAG, "بروتوكول غير مدعوم: " + protocol);
        }
    }

    /**
     * تحليل حزمة TCP
     */
    private void analyzeTcpPacket(ByteBuffer packet, int ipHeaderLength, int payloadLength, int sourceIp, int destinationIp) {
        if (payloadLength < 20) { // الحد الأدنى لحجم رأس TCP هو 20 بايت
            Log.d(TAG, "حزمة TCP قصيرة جداً.");
            return;
        }

        // تحديد موقع رأس TCP
        packet.position(ipHeaderLength);

        // قراءة المنافذ
        int sourcePort = packet.getShort() & 0xFFFF;
        int destinationPort = packet.getShort() & 0xFFFF;

        // تخطي حقول Sequence Number و Acknowledgment Number
        packet.getInt(); // Sequence Number
        packet.getInt(); // Acknowledgment Number

        // قراءة طول رأس TCP
        byte dataOffsetAndFlags = packet.get();
        int tcpHeaderLength = ((dataOffsetAndFlags >> 4) & 0x0F) * 4;

        // تخطي باقي رأس TCP
        packet.position(ipHeaderLength + tcpHeaderLength);

        // تحديد موقع حمولة البيانات (Payload)
        int dataLength = payloadLength - tcpHeaderLength;

        if (dataLength > 0) {
            // هنا يتم استخراج البيانات وتحليلها
            byte[] data = new byte[dataLength];
            packet.get(data);
            
            // تحويل البيانات إلى سلسلة نصية (افتراضًا أنها بيانات نصية مثل HTTP أو WebSocket)
            String dataString = new String(data);
            
            // **منطق تصفية البيانات وتحليلها بواسطة الذكاء الاصطناعي**
            // نفترض أن بيانات جولة اللعبة تأتي في شكل JSON عبر اتصال TCP/WebSocket
            
            if (isGameData(dataString)) {
                try {
                    // محاولة تحليل البيانات كجولة لعبة
                    CrashRound round = gson.fromJson(dataString, CrashRound.class);
                    
                    // تمرير البيانات إلى نظام الذكاء الاصطناعي للتحليل الفوري
                    aiSystem.analyzeNewRound(round);
                    
                    // **الخطوة التالية: إرسال التنبؤ إلى المساعد الثاني**
                    // سيتم تنفيذ هذا في المرحلة الخامسة (WebSockets)
                    
                    Log.w(TAG, String.format("Game Data Captured: %s:%d -> %s:%d | Multiplier: %.2f",
                            ipIntToString(sourceIp), sourcePort, ipIntToString(destinationIp), destinationPort, round.getMultiplier()));
                            
                } catch (JsonSyntaxException e) {
                    // قد تكون البيانات ليست جولة لعبة كاملة أو تنسيقها غير صحيح
                    Log.d(TAG, "TCP Data: " + dataString.substring(0, Math.min(dataString.length(), 100)));
                }
            }
        }
    }

    /**
     * تحليل حزمة UDP
     */
    private void analyzeUdpPacket(ByteBuffer packet, int ipHeaderLength, int payloadLength, int sourceIp, int destinationIp) {
        // UDP عادة لا تحمل بيانات اللعبة الحساسة، لكن يمكن استخدامها لبعض التحديثات
        // في هذا السيناريو، سنركز على TCP/WebSocket حيث يتم نقل بيانات الجولات عادةً.
        // يمكن إضافة منطق تحليل UDP هنا إذا لزم الأمر.
    }

    /**
     * تحويل عنوان IP من عدد صحيح إلى سلسلة نصية
     */
    /**
     * دالة مساعدة لتحديد ما إذا كانت البيانات هي بيانات جولة لعبة.
     * يجب تعديل هذا المنطق ليتناسب مع التنسيق الفعلي لبيانات اللعبة.
     * نفترض أن بيانات الجولة تحتوي على حقل "multiplier" و "game_id".
     */
    private boolean isGameData(String data) {
        // تصفية سريعة: يجب أن تكون البيانات بتنسيق JSON وتحتوي على كلمات مفتاحية
        return data.contains("\"multiplier\"") && data.contains("\"game_id\"");
    }

    /**
     * تحويل عنوان IP من عدد صحيح إلى سلسلة نصية
     */
    private String ipIntToString(int ip) {
        return String.format("%d.%d.%d.%d",
                (ip >> 24) & 0xFF,
                (ip >> 16) & 0xFF,
                (ip >> 8) & 0xFF,
                ip & 0xFF);
    }
}
