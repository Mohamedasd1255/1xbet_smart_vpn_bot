package com.secure1xbot;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.secure1xbot.ai.HybridAISystem;
import com.secure1xbot.cloud.CloudDeploymentManager;
import com.secure1xbot.data.LiveDataCollectionSystem;
import com.secure1xbot.sync.DataSyncManager;

/**
 * تطبيق البوت الرئيسي
 * يقوم بتهيئة جميع المكونات الأساسية للبوت
 */
	public class CrashBotApplication extends Application {
	    // ... (باقي الكود) ...
    private static final String TAG = "CrashBotApplication";
    private static final String PREFS_NAME = "CrashBotPrefs";
    
    private static CrashBotApplication instance;
    
    // مكونات النظام
    private HybridAISystem aiSystem;
    private LiveDataCollectionSystem dataCollectionSystem;
    private DataSyncManager dataSyncManager;
    private CloudDeploymentManager cloudDeploymentManager;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "بدء تهيئة تطبيق البوت");
        
        instance = this;
        
        // تهيئة مكونات النظام
        initializeComponents();
        
	        Log.d(TAG, "تم تهيئة تطبيق البوت بنجاح");
	    }
	
	    @Override
	    public void onTerminate() {
	        super.onTerminate();
	        if (aiSystem != null) {
	            aiSystem.close(); // إغلاق WebSocketSender و TFLite Interpreter
	        }
	    }
    
    /**
     * تهيئة مكونات النظام
     */
    private void initializeComponents() {
        // تهيئة نظام جمع البيانات
        // تهيئة نظام جمع البيانات، والذي يتضمن الآن WebSocket و Room Database
        dataCollectionSystem = new LiveDataCollectionSystem(this);
        
        // تهيئة نظام الذكاء الاصطناعي
        aiSystem = new HybridAISystem(this);
        
        // تهيئة مدير المزامنة (قد يحتاج إلى تعديل ليتكامل مع البيانات اللحظية)
        dataSyncManager = new DataSyncManager(this);
        
        // تهيئة مدير النشر السحابي
        cloudDeploymentManager = new CloudDeploymentManager(this);
        
        // تكوين مدير النشر السحابي إذا كانت المعلومات متوفرة (قد يحتاج إلى تحديث)
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String apiKey = prefs.getString("cloud_api_key", "");
        String endpoint = prefs.getString("cloud_endpoint", "");
        
        if (!apiKey.isEmpty() && !endpoint.isEmpty()) {
            cloudDeploymentManager.configure(apiKey, endpoint);
        }

        // بدء خدمة مراقبة اللعبة (التي أصبحت الآن تستمع لبيانات WebSocket)
        // يمكن بدء الخدمة هنا أو عند الحاجة إليها في واجهة المستخدم
        // Intent serviceIntent = new Intent(this, GameMonitorService.class);
        // startService(serviceIntent);
    }
    
    /**
     * الحصول على مثيل التطبيق
     */
    public static CrashBotApplication getInstance() {
        return instance;
    }
    
    /**
     * الحصول على نظام الذكاء الاصطناعي
     */
    public HybridAISystem getAISystem() {
        return aiSystem;
    }
    
    /**
     * الحصول على نظام جمع البيانات
     */
    public LiveDataCollectionSystem getDataCollectionSystem() {
        return dataCollectionSystem;
    }
    
    /**
     * الحصول على مدير المزامنة
     */
    public DataSyncManager getDataSyncManager() {
        return dataSyncManager;
    }
    
    /**
     * الحصول على مدير النشر السحابي
     */
    public CloudDeploymentManager getCloudDeploymentManager() {
        return cloudDeploymentManager;
    }
    
    /**
     * حفظ الإعدادات
     */
    public void saveSettings(String cloudApiKey, String cloudEndpoint, int syncInterval) {
        // يجب تحديث هذه الدالة لتعالج إعدادات WebSocket إذا كانت قابلة للتكوين
        // ويمكن أن تتضمن إعادة تشغيل WebSocketClient إذا تغير عنوان URL

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        
        editor.putString("cloud_api_key", cloudApiKey);
        editor.putString("cloud_endpoint", cloudEndpoint);
        editor.putInt("sync_interval", syncInterval);
        
        editor.apply();
        
        // تحديث مكونات النظام
        if (!cloudApiKey.isEmpty() && !cloudEndpoint.isEmpty()) {
            cloudDeploymentManager.configure(cloudApiKey, cloudEndpoint);
        }
        
        dataSyncManager.configure(cloudEndpoint, syncInterval);
        
        Log.d(TAG, "تم حفظ الإعدادات بنجاح");
    }
}
