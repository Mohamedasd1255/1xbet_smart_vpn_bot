package com.secure1xbot.services;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.ai.HybridAISystem;
import com.secure1xbot.data.CrashRound;
import com.secure1xbot.data.LiveDataCollectionSystem;

import com.secure1xbot.data.LiveDataCollectionSystem.DataCollectionListener;

/**
 * خدمة مراقبة اللعبة
 * تقوم بمراقبة اللعبة واكتشاف الجولات الجديدة
 */
public class GameMonitorService extends Service implements DataCollectionListener {
    private static final String TAG = "GameMonitorService";
    
    private Handler handler;
    private LiveDataCollectionSystem dataCollectionSystem;
    
    private static boolean isRunning = false;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "خدمة مراقبة اللعبة تم إنشاؤها");
        
        handler = new Handler();
        dataCollectionSystem = CrashBotApplication.getInstance().getDataCollectionSystem();
        dataCollectionSystem.addListener(this); // تسجيل الخدمة كمستمع لجمع البيانات
        
        isRunning = true;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "خدمة مراقبة اللعبة تم بدء تشغيلها");
        
        // لم يعد هناك مؤقت مراقبة، سيتم تشغيل التنبؤ عند تلقي بيانات جديدة
        
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "خدمة مراقبة اللعبة تم تدميرها");
        if (dataCollectionSystem != null) {
            dataCollectionSystem.removeListener(this);
        }
        isRunning = false;
    }
    
    /**
     * بدء مؤقت المراقبة
     */

    
    /**
     * مراقبة اللعبة
     */

    
    /**
     * تحديث التنبؤ
     */
    @Override
    public void onNewRoundCollected(CrashRound round) {
        // يتم استدعاء هذه الدالة عندما يتم جمع جولة جديدة عبر WebSocket
        Log.d(TAG, "جولة جديدة تم جمعها: " + round + ". تحديث التنبؤ...");
        updatePrediction();
    }

    private void updatePrediction() {
        HybridAISystem aiSystem = CrashBotApplication.getInstance().getAISystem();
        
        aiSystem.predictNow(result -> {
            if (result != null) {
                Log.d(TAG, "تم تحديث التنبؤ: " + result.getPredictedValue() + "x (" + (result.getConfidence() * 100) + "%)");
            }
        });
    }
    
    /**
     * التحقق مما إذا كانت الخدمة قيد التشغيل
     */
    public static boolean isRunning() {
        return isRunning;
    }
}
