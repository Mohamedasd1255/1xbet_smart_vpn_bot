package com.secure1xbot.ui;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.R;
import com.secure1xbot.services.AutoSyncService;

/**
 * نشاط الإعدادات
 */
public class SettingsActivity extends AppCompatActivity {
    private static final String TAG = "SettingsActivity";
    
    private EditText cloudApiKeyEditText;
    private EditText cloudEndpointEditText;
    private Spinner syncIntervalSpinner;
    private Button saveButton;
    private Button exportDataButton;
    private Button importDataButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        // إعداد شريط الإجراءات
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("الإعدادات");
        }
        
        // تهيئة عناصر واجهة المستخدم
        initializeUI();
        
        // تحميل الإعدادات الحالية
        loadCurrentSettings();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    /**
     * تهيئة عناصر واجهة المستخدم
     */
    private void initializeUI() {
        cloudApiKeyEditText = findViewById(R.id.cloudApiKeyEditText);
        cloudEndpointEditText = findViewById(R.id.cloudEndpointEditText);
        syncIntervalSpinner = findViewById(R.id.syncIntervalSpinner);
        saveButton = findViewById(R.id.saveButton);
        exportDataButton = findViewById(R.id.exportDataButton);
        importDataButton = findViewById(R.id.importDataButton);
        
        // إعداد مستمعي النقر
        saveButton.setOnClickListener(v -> saveSettings());
        exportDataButton.setOnClickListener(v -> exportData());
        importDataButton.setOnClickListener(v -> importData());
    }
    
    /**
     * تحميل الإعدادات الحالية
     */
    private void loadCurrentSettings() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        
        String apiKey = prefs.getString("cloud_api_key", "");
        String endpoint = prefs.getString("cloud_endpoint", "https://cloud-api.secure1xbot.com");
        int syncInterval = prefs.getInt("sync_interval", 30);
        
        cloudApiKeyEditText.setText(apiKey);
        cloudEndpointEditText.setText(endpoint);
        
        // تعيين قيمة فترة المزامنة في القائمة المنسدلة
        int spinnerPosition = 0;
        switch (syncInterval) {
            case 15:
                spinnerPosition = 0;
                break;
            case 30:
                spinnerPosition = 1;
                break;
            case 60:
                spinnerPosition = 2;
                break;
            case 120:
                spinnerPosition = 3;
                break;
        }
        syncIntervalSpinner.setSelection(spinnerPosition);
    }
    
    /**
     * حفظ الإعدادات
     */
    private void saveSettings() {
        String apiKey = cloudApiKeyEditText.getText().toString().trim();
        String endpoint = cloudEndpointEditText.getText().toString().trim();
        
        // التحقق من صحة عنوان URL
        if (!endpoint.isEmpty() && !endpoint.startsWith("http")) {
            endpoint = "https://" + endpoint;
        }
        
        // الحصول على فترة المزامنة من القائمة المنسدلة
        int syncInterval;
        switch (syncIntervalSpinner.getSelectedItemPosition()) {
            case 0:
                syncInterval = 15;
                break;
            case 1:
                syncInterval = 30;
                break;
            case 2:
                syncInterval = 60;
                break;
            case 3:
                syncInterval = 120;
                break;
            default:
                syncInterval = 30;
        }
        
        // حفظ الإعدادات
        CrashBotApplication.getInstance().saveSettings(apiKey, endpoint, syncInterval);
        
        // تحديث فترة المزامنة التلقائية
        AutoSyncService.updateSyncInterval(syncInterval);
        
        Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show();
        
        // إنهاء النشاط
        finish();
    }
    
    /**
     * تصدير البيانات
     */
    private void exportData() {
        boolean success = CrashBotApplication.getInstance().getDataCollectionSystem().exportData();
        
        if (success) {
            Toast.makeText(this, "تم تصدير البيانات بنجاح", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "فشل تصدير البيانات", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * استيراد البيانات
     */
    private void importData() {
        boolean success = CrashBotApplication.getInstance().getDataCollectionSystem().importData();
        
        if (success) {
            Toast.makeText(this, "تم استيراد البيانات بنجاح", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "فشل استيراد البيانات", Toast.LENGTH_SHORT).show();
        }
    }
}
