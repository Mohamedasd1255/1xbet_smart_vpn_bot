package com.secure1xbot.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.R;
import com.secure1xbot.ai.HybridAISystem;
import com.secure1xbot.ai.PredictionResult;
import com.secure1xbot.data.CrashRound;
import com.secure1xbot.data.LiveDataCollectionSystem;
import com.secure1xbot.ui.MainActivity;

import java.util.Timer;
import java.util.TimerTask;

/**
 * خدمة النافذة العائمة التي تعرض تنبؤات الذكاء الاصطناعي
 */
public class FloatingOverlayService extends Service {
    private static final String TAG = "FloatingOverlayService";
    private static final String CHANNEL_ID = "CrashBotServiceChannel";
    private static final int NOTIFICATION_ID = 1;
    
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    
    private TextView predictedValueTextView;
    private TextView confidenceLevelTextView;
    private TextView adviceTextView;
    private TextView sourceTextView;
    
    private Timer predictionTimer;
    private Handler handler;
    
    private static boolean isRunning = false;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "خدمة النافذة العائمة تم إنشاؤها");
        
        // إنشاء قناة الإشعارات (مطلوب لنظام Android 8.0+)
        createNotificationChannel();
        
        // بدء الخدمة في المقدمة
        startForeground(NOTIFICATION_ID, createNotification());
        
        // تهيئة مدير النوافذ
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        // تهيئة معالج الواجهة الرئيسية
        handler = new Handler();
        
        // إنشاء النافذة العائمة
        createFloatingWindow();
        
        // بدء مؤقت التنبؤ
        startPredictionTimer();
        
        isRunning = true;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "خدمة النافذة العائمة تم بدء تشغيلها");
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "خدمة النافذة العائمة تم تدميرها");
        
        // إيقاف مؤقت التنبؤ
        if (predictionTimer != null) {
            predictionTimer.cancel();
            predictionTimer = null;
        }
        
        // إزالة النافذة العائمة
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
            floatingView = null;
        }
        
        isRunning = false;
    }
    
    /**
     * إنشاء قناة الإشعارات
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Crash Bot Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("قناة إشعارات خدمة Crash Bot");
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    /**
     * إنشاء إشعار الخدمة
     */
    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_IMMUTABLE
        );
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Crash Bot نشط")
                .setContentText("البوت يعمل ويراقب اللعبة")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .build();
    }
    
    /**
     * إنشاء النافذة العائمة
     */
    private void createFloatingWindow() {
        // تهيئة معلمات النافذة
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        
        // تعيين موضع النافذة
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;
        
        // تضخيم تخطيط النافذة العائمة
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        floatingView = inflater.inflate(R.layout.floating_overlay, null);
        
        // الحصول على مراجع لعناصر واجهة المستخدم
        predictedValueTextView = floatingView.findViewById(R.id.predictedValueTextView);
        confidenceLevelTextView = floatingView.findViewById(R.id.confidenceLevelTextView);
        adviceTextView = floatingView.findViewById(R.id.adviceTextView);
        sourceTextView = floatingView.findViewById(R.id.sourceTextView);
        Button closeButton = floatingView.findViewById(R.id.closeButton);
        Button refreshButton = floatingView.findViewById(R.id.refreshButton);
        
        // إعداد مستمع النقر لزر الإغلاق
        closeButton.setOnClickListener(v -> stopSelf());
        
        // إعداد مستمع النقر لزر التحديث
        refreshButton.setOnClickListener(v -> refreshPrediction());
        
        // إعداد مستمع اللمس للسحب
        setupTouchListener();
        
        // إضافة النافذة إلى مدير النوافذ
        windowManager.addView(floatingView, params);
    }
    
    /**
     * إعداد مستمع اللمس للسحب
     */
    private void setupTouchListener() {
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }
    
    /**
     * بدء مؤقت التنبؤ
     */
    private void startPredictionTimer() {
        predictionTimer = new Timer();
        predictionTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                // محاكاة اكتشاف جولة جديدة
                simulateNewRound();
                
                // تحديث التنبؤ
                refreshPrediction();
            }
        }, 5000, 30000); // تحديث كل 30 ثانية بعد تأخير أولي 5 ثوانٍ
    }
    
    /**
     * محاكاة اكتشاف جولة جديدة
     */
    private void simulateNewRound() {
        // في التطبيق الفعلي، سيتم اكتشاف الجولات من بيانات اللعبة
        // هنا نقوم بمحاكاة ذلك
        
        LiveDataCollectionSystem dataSystem = CrashBotApplication.getInstance().getDataCollectionSystem();
        
        // إنشاء جولة عشوائية للمحاكاة
        float multiplier = 1.0f + (float) (Math.random() * 5.0);
        CrashRound round = new CrashRound(System.currentTimeMillis(), multiplier);
        
        // جمع الجولة
        dataSystem.collectRound(round);
        
        Log.d(TAG, "تم اكتشاف جولة جديدة (محاكاة): " + round);
    }
    
    /**
     * تحديث التنبؤ
     */
    private void refreshPrediction() {
        HybridAISystem aiSystem = CrashBotApplication.getInstance().getAISystem();
        
        aiSystem.predictNow(result -> {
            handler.post(() -> updateUI(result));
        });
    }
    
    /**
     * تحديث واجهة المستخدم بنتيجة التنبؤ
     */
    private void updateUI(PredictionResult result) {
        if (result != null) {
            predictedValueTextView.setText(String.format("%.2fx", result.getPredictedValue()));
            confidenceLevelTextView.setText(String.format("%.1f%%", result.getConfidence() * 100));
            sourceTextView.setText(getModelName(result.getSource()));
            adviceTextView.setText(getAdvice(result));
            
            // تغيير لون النص بناءً على النصيحة
            int color = getAdviceColor(result);
            adviceTextView.setTextColor(color);
        }
    }
    
    /**
     * الحصول على اسم النموذج
     */
    private String getModelName(String source) {
        switch (source) {
            case "main":
                return "النموذج الرئيسي";
            case "simple":
                return "النموذج البسيط";
            case "hybrid":
                return "النموذج الهجين";
            default:
                return "غير معروف";
        }
    }
    
    /**
     * الحصول على النصيحة بناءً على نتيجة التنبؤ
     */
    private String getAdvice(PredictionResult prediction) {
        float value = prediction.getPredictedValue();
        float confidence = prediction.getConfidence();
        
        if (confidence < 0.5) {
            return "غير موثوق";
        } else if (value < 1.5) {
            return "مخاطرة عالية";
        } else if (value < 2.0) {
            return "مخاطرة متوسطة";
        } else {
            return "آمن نسبياً";
        }
    }
    
    /**
     * الحصول على لون النصيحة
     */
    private int getAdviceColor(PredictionResult prediction) {
        float value = prediction.getPredictedValue();
        float confidence = prediction.getConfidence();
        
        if (confidence < 0.5) {
            return 0xFF888888; // رمادي
        } else if (value < 1.5) {
            return 0xFFFF0000; // أحمر
        } else if (value < 2.0) {
            return 0xFFFF8800; // برتقالي
        } else {
            return 0xFF00AA00; // أخضر
        }
    }
    
    /**
     * التحقق مما إذا كانت الخدمة قيد التشغيل
     */
    public static boolean isRunning() {
        return isRunning;
    }
}
