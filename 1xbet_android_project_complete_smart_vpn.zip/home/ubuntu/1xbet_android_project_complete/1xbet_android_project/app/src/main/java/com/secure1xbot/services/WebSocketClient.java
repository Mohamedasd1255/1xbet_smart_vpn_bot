package com.secure1xbot.services;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class WebSocketClient {

    private static final String TAG = "WebSocketClient";
    private WebSocket webSocket;
    private final String serverUrl;
    private final WebSocketMessageListener listener;

    public WebSocketClient(String serverUrl, WebSocketMessageListener listener) {
        this.serverUrl = serverUrl;
        this.listener = listener;
    }

    public void connect() {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(serverUrl).build();
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(@NonNull WebSocket webSocket, @NonNull Response response) {
                Log.d(TAG, "WebSocket connection opened");
                if (listener != null) {
                    listener.onConnect();
                }
            }

            @Override
            public void onMessage(@NonNull WebSocket webSocket, @NonNull String text) {
                Log.d(TAG, "WebSocket message received: " + text);
                if (listener != null) {
                    listener.onMessage(text);
                }
            }

            @Override
            public void onMessage(@NonNull WebSocket webSocket, @NonNull ByteString bytes) {
                // Handle binary messages if needed
            }

            @Override
            public void onClosing(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
                webSocket.close(1000, null);
                Log.d(TAG, "WebSocket closing: " + code + " / " + reason);
            }

            @Override
            public void onClosed(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
                Log.d(TAG, "WebSocket connection closed: " + code + " / " + reason);
                if (listener != null) {
                    listener.onDisconnect();
                }
            }

            @Override
            public void onFailure(@NonNull WebSocket webSocket, @NonNull Throwable t, @Nullable Response response) {
                Log.e(TAG, "WebSocket connection failure", t);
                if (listener != null) {
                    listener.onError(t.getMessage());
                }
            }
        });
    }

    public void disconnect() {
        if (webSocket != null) {
            webSocket.close(1000, "Client disconnected");
        }
    }

    public void sendMessage(String message) {
        if (webSocket != null) {
            webSocket.send(message);
        }
    }

    public interface WebSocketMessageListener {
        void onConnect();
        void onDisconnect();
        void onMessage(String message);
        void onError(String error);
    }
}

