package com.secure1xbot.ai;

import android.content.Context;
import android.util.Log;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.data.CrashRound;
import com.secure1xbot.data.LiveDataCollectionSystem;
import com.secure1xbot.network.WebSocketSender;

import org.tensorflow.lite.Interpreter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * نظام الذكاء الاصطناعي الهجين الذي يجمع بين النموذج الرئيسي المدرب مسبقاً والنموذج البسيط للتعلم على الجهاز
 */
public class HybridAISystem {
    private static final String TAG = "HybridAISystem";
    
    private Context context;
    private Interpreter mainModel;
    private SimpleOnDeviceModel simpleModel;
    private WebSocketSender webSocketSender;
    private boolean isInitialized;
    
    // معلمات النموذج
    // يجب أن يكون طول التسلسل متوافقًا مع SimpleOnDeviceModel
    private static final int SEQUENCE_LENGTH = 10;
    private static final int FEATURE_COUNT = 1;
    
    // معالج العمليات الخلفية
    private final Executor executor = Executors.newSingleThreadExecutor();
    
    /**
     * إنشاء نظام الذكاء الاصطناعي الهجين
     * 
     * @param context سياق التطبيق
     */
    public HybridAISystem(Context context) {
        this.context = context;
        this.isInitialized = false;
        
        // تهيئة النموذج البسيط
        this.simpleModel = new SimpleOnDeviceModel(context);
        
        // تهيئة مرسل الويب سوكيت
        this.webSocketSender = new WebSocketSender();
        
        // محاولة تحميل النموذج الرئيسي
        loadMainModel();
    }
    
    /**
     * تحميل النموذج الرئيسي
     */
    private void loadMainModel() {
        executor.execute(() -> {
            try {
                // البحث عن ملف النموذج في مجلد الأصول
                File modelFile = new File(context.getFilesDir(), "models/main_model.tflite");
                
                if (modelFile.exists()) {
                    // تحميل النموذج من الملف
                    MappedByteBuffer modelBuffer = loadModelFile(modelFile);
                    
                    // إنشاء مفسر TensorFlow Lite
                    Interpreter.Options options = new Interpreter.Options();
                    mainModel = new Interpreter(modelBuffer, options);
                    
                    Log.d(TAG, "تم تحميل النموذج الرئيسي بنجاح");
                } else {
                    // إنشاء نموذج افتراضي بسيط إذا لم يتم العثور على ملف النموذج
                    Log.d(TAG, "لم يتم العثور على ملف النموذج الرئيسي (main_model.tflite) في مجلد التطبيق. يرجى التأكد من توفيره أو تدريبه ونشره. سيتم استخدام النموذج البسيط فقط في الوقت الحالي.");
                    mainModel = null;
                    // ملاحظة: لدمج نموذج رئيسي أقوى، يجب توفير ملف main_model.tflite محسّن هنا.
                    // يمكن تدريب هذا النموذج خارج الجهاز باستخدام بيانات أكبر وأكثر تعقيدًا ثم تحويله إلى تنسيق TFLite.
                    // يمكن أيضًا استخدام Firebase ML أو Google Cloud AI Platform لنشر نموذج سحابي أقوى والاستفادة منه عبر API.
                    // يجب تحديث آلية التحميل هنا لتشمل التحقق من إصدار النموذج وتحديثه إذا لزم الأمر.
                }
                
                isInitialized = true;
            } catch (Exception e) {
                Log.e(TAG, "فشل تحميل النموذج الرئيسي", e);
                mainModel = null;
            }
        });
    }
    
    /**
     * تحميل ملف النموذج
     */
    private MappedByteBuffer loadModelFile(File modelFile) throws Exception {
        FileInputStream inputStream = new FileInputStream(modelFile);
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = 0;
        long declaredLength = fileChannel.size();
        MappedByteBuffer buffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        inputStream.close();
        return buffer;
    }
    
    /**
     * التنبؤ بالجولة التالية
     * 
     * @param callback استدعاء عند اكتمال التنبؤ
     */
	    /**
	     * تحليل جولة جديدة والتنبؤ الفوري
	     * 
	     * @param newRound الجولة الجديدة التي تم اعتراضها من VPN
	     */
	    public void analyzeNewRound(CrashRound newRound) {
	        executor.execute(() -> {
	            try {
	                // 1. حفظ الجولة الجديدة (للتدريب المستقبلي)
	                LiveDataCollectionSystem dataSystem = CrashBotApplication.getInstance().getDataCollectionSystem();
	                dataSystem.saveRound(newRound);
	                
	                if (!isInitialized) {
	                    Log.e(TAG, "نظام الذكاء الاصطناعي غير مهيأ");
	                    return;
	                }
	                
	                // 2. الحصول على آخر 10 جولات (بما في ذلك الجولة الجديدة)
	                List<CrashRound> lastRounds = dataSystem.getLastRounds(SEQUENCE_LENGTH);
	                
	                if (lastRounds.size() < 5) {
	                    Log.d(TAG, "لا توجد بيانات كافية للتنبؤ");
	                    return;
	                }
	                
	                // 3. التنبؤ باستخدام النموذج الرئيسي
	                PredictionResult mainPrediction = null;
	                if (mainModel != null) {
	                    mainPrediction = predictWithMainModel(lastRounds);
	                }
	                
	                // 4. التنبؤ باستخدام النموذج البسيط
	                PredictionResult simplePrediction = simpleModel.predict(lastRounds);
	                
	                // 5. دمج التنبؤات
	                PredictionResult finalPrediction = combineResults(mainPrediction, simplePrediction);
	                
	                Log.d(TAG, "تم التنبؤ بنجاح: " + finalPrediction);
	                
	                // 6. إرسال التنبؤ الفوري إلى المساعد الثاني
	                webSocketSender.sendPrediction(finalPrediction);
	                
	            } catch (Exception e) {
	                Log.e(TAG, "فشل التنبؤ الفوري", e);
	            }
	        });
	    }
    
    /**
     * التنبؤ باستخدام النموذج الرئيسي
     */
    private PredictionResult predictWithMainModel(List<CrashRound> rounds) {
        try {
            // تحويل البيانات إلى تنسيق مناسب للنموذج
            // تحويل البيانات إلى تنسيق مناسب للنموذج الرئيسي
            // يمكن تحسين هذه العملية لزيادة الكفاءة
            float[][][] input = new float[1][SEQUENCE_LENGTH][FEATURE_COUNT];
            
            // ملء مصفوفة الإدخال بالبيانات
            for (int i = 0; i < Math.min(rounds.size(), SEQUENCE_LENGTH); i++) {
                // التأكد من أن ترتيب البيانات صحيح للنموذج (الأحدث أولاً أو الأقدم أولاً)
                input[0][i][0] = rounds.get(rounds.size() - SEQUENCE_LENGTH + i).getMultiplier();
            }
            
            // إنشاء مصفوفة الإخراج
            float[][] output = new float[1][1];
            
            // تشغيل التنبؤ
            mainModel.run(input, output);
            
            // استخراج القيمة المتنبأ بها
            float predictedValue = output[0][0];
            
            // تقدير الثقة (في التطبيق الفعلي، قد يتم حسابها بطريقة أكثر تعقيداً)
            float confidence = 0.8f;
            
            return new PredictionResult(predictedValue, confidence, "main");
        } catch (Exception e) {
            Log.e(TAG, "فشل التنبؤ باستخدام النموذج الرئيسي", e);
            return null;
        }
    }
    
    /**
     * دمج نتائج التنبؤ من النموذجين
     */
    private PredictionResult combineResults(PredictionResult mainPrediction, PredictionResult simplePrediction) {
        if (mainPrediction == null && simplePrediction == null) {
            // إذا فشل كلا النموذجين، إرجاع قيمة افتراضية
            return new PredictionResult(1.5f, 0.3f, "hybrid");
        } else if (mainPrediction == null) {
            // إذا فشل النموذج الرئيسي، استخدام النموذج البسيط
            return simplePrediction;
        } else if (simplePrediction == null) {
            // إذا فشل النموذج البسيط، استخدام النموذج الرئيسي
            return mainPrediction;
        }
        
        // دمج النتائج بناءً على الثقة
        float totalConfidence = mainPrediction.getConfidence() + simplePrediction.getConfidence();
        float mainWeight = mainPrediction.getConfidence() / totalConfidence;
        float simpleWeight = simplePrediction.getConfidence() / totalConfidence;
        
        float combinedValue = (mainPrediction.getPredictedValue() * mainWeight) +
                             (simplePrediction.getPredictedValue() * simpleWeight);
        
        // استخدام أعلى قيمة ثقة من النموذجين
        float combinedConfidence = Math.max(mainPrediction.getConfidence(), simplePrediction.getConfidence());
        
        return new PredictionResult(combinedValue, combinedConfidence, "hybrid");
    }
    
	    /**
	     * إغلاق مرسل الويب سوكيت
	     */
	    public void close() {
	        if (mainModel != null) {
	            mainModel.close();
	        }
	        if (webSocketSender != null) {
	            webSocketSender.close();
	        }
	    }
	    
	    /**
	     * تحديث النموذج الرئيسي
	     */
	    public void updateMainModel(File newModelFile) {
        executor.execute(() -> {
            try {
                if (newModelFile == null || !newModelFile.exists()) {
                    Log.e(TAG, "ملف النموذج الجديد غير موجود");
                    return;
                }
                
                // إغلاق النموذج الحالي إذا كان موجوداً
                if (mainModel != null) {
                    mainModel.close();
                }
                
                // نسخ ملف النموذج الجديد إلى مجلد النماذج
                File modelDir = new File(context.getFilesDir(), "models");
                if (!modelDir.exists()) {
                    modelDir.mkdirs();
                }
                
                File targetFile = new File(modelDir, "main_model.tflite");
                
                // نسخ الملف
                FileInputStream fis = new FileInputStream(newModelFile);
                FileOutputStream fos = new FileOutputStream(targetFile);
                byte[] buffer = new byte[1024];
                int length;
                
                while ((length = fis.read(buffer)) > 0) {
                    fos.write(buffer, 0, length);
                }
                
                fos.close();
                fis.close();
                
                // تحميل النموذج الجديد
                MappedByteBuffer modelBuffer = loadModelFile(targetFile);
                
                // إنشاء مفسر TensorFlow Lite جديد
                Interpreter.Options options = new Interpreter.Options();
                mainModel = new Interpreter(modelBuffer, options);
                
                Log.d(TAG, "تم تحديث النموذج الرئيسي بنجاح");
            } catch (Exception e) {
                Log.e(TAG, "فشل تحديث النموذج الرئيسي", e);
            }
        });
    }
    
    /**
     * الحصول على النموذج البسيط
     */
    public SimpleOnDeviceModel getSimpleModel() {
        return simpleModel;
    }
    
    /**
     * واجهة استدعاء التنبؤ
     */
	    // تم إزالة PredictionCallback لأنه لم يعد مستخدمًا بعد التحول إلى التحليل الفوري
}
