package com.secure1xbot.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.secure1xbot.CrashBotApplication;
import com.secure1xbot.R;
import com.secure1xbot.services.AutoSyncService;
import com.secure1xbot.services.FloatingOverlayService;
import com.secure1xbot.services.GameMonitorService;
import com.secure1xbot.sync.DataSyncManager;

/**
 * النشاط الرئيسي للتطبيق
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    
    private TextView statusTextView;
    private TextView collectedDataTextView;
    private TextView lastSyncTextView;
    private Button startButton;
    private Button stopButton;
    private Button settingsButton;
    private Button syncNowButton;
    private Switch autoSyncSwitch;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // تهيئة عناصر واجهة المستخدم
        initializeUI();
        
        // تحديث حالة واجهة المستخدم
        updateUIState();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        // تحديث حالة واجهة المستخدم
        updateUIState();
    }
    
    /**
     * تهيئة عناصر واجهة المستخدم
     */
    private void initializeUI() {
        statusTextView = findViewById(R.id.statusTextView);
        collectedDataTextView = findViewById(R.id.collectedDataTextView);
        lastSyncTextView = findViewById(R.id.lastSyncTextView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        settingsButton = findViewById(R.id.settingsButton);
        syncNowButton = findViewById(R.id.syncNowButton);
        autoSyncSwitch = findViewById(R.id.autoSyncSwitch);
        
        // إعداد مستمعي النقر
        startButton.setOnClickListener(v -> startServices());
        stopButton.setOnClickListener(v -> stopServices());
        settingsButton.setOnClickListener(v -> openSettings());
        syncNowButton.setOnClickListener(v -> syncNow());
        autoSyncSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> toggleAutoSync(isChecked));
    }
    
    /**
     * تحديث حالة واجهة المستخدم
     */
    private void updateUIState() {
        boolean isRunning = FloatingOverlayService.isRunning();
        
        // تحديث نص الحالة
        statusTextView.setText(isRunning ? "نشط" : "غير نشط");
        statusTextView.setTextColor(isRunning ? 0xFF00AA00 : 0xFFFF0000);
        
        // تحديث عدد البيانات المجمعة
        int dataCount = CrashBotApplication.getInstance().getDataCollectionSystem().getCollectedRoundsCount();
        collectedDataTextView.setText(String.valueOf(dataCount));
        
        // تحديث وقت آخر مزامنة
        String lastSyncTime = CrashBotApplication.getInstance().getDataSyncManager().getLastSyncTime();
        lastSyncTextView.setText(lastSyncTime);
        
        // تحديث حالة زر التشغيل/الإيقاف
        startButton.setEnabled(!isRunning);
        stopButton.setEnabled(isRunning);
        
        // تحديث حالة مفتاح المزامنة التلقائية
        autoSyncSwitch.setChecked(AutoSyncService.isRunning());
    }
    
    /**
     * بدء تشغيل الخدمات
     */
    private void startServices() {
        // بدء خدمة النافذة العائمة
        Intent overlayIntent = new Intent(this, FloatingOverlayService.class);
        startService(overlayIntent);
        
        // بدء خدمة مراقبة اللعبة
        Intent monitorIntent = new Intent(this, GameMonitorService.class);
        startService(monitorIntent);
        
        // تحديث حالة واجهة المستخدم
        updateUIState();
        
        Toast.makeText(this, "تم بدء تشغيل البوت", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * إيقاف تشغيل الخدمات
     */
    private void stopServices() {
        // إيقاف خدمة النافذة العائمة
        Intent overlayIntent = new Intent(this, FloatingOverlayService.class);
        stopService(overlayIntent);
        
        // إيقاف خدمة مراقبة اللعبة
        Intent monitorIntent = new Intent(this, GameMonitorService.class);
        stopService(monitorIntent);
        
        // تحديث حالة واجهة المستخدم
        updateUIState();
        
        Toast.makeText(this, "تم إيقاف تشغيل البوت", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * فتح إعدادات التطبيق
     */
    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }
    
    /**
     * مزامنة البيانات الآن
     */
    private void syncNow() {
        DataSyncManager syncManager = CrashBotApplication.getInstance().getDataSyncManager();
        
        Toast.makeText(this, "جاري المزامنة...", Toast.LENGTH_SHORT).show();
        
        syncManager.syncNow(success -> {
            runOnUiThread(() -> {
                if (success) {
                    Toast.makeText(this, "تمت المزامنة بنجاح", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "فشلت المزامنة", Toast.LENGTH_SHORT).show();
                }
                
                // تحديث حالة واجهة المستخدم
                updateUIState();
            });
        });
    }
    
    /**
     * تبديل حالة المزامنة التلقائية
     */
    private void toggleAutoSync(boolean enabled) {
        Intent intent = new Intent(this, AutoSyncService.class);
        
        if (enabled) {
            startService(intent);
            Toast.makeText(this, "تم تفعيل المزامنة التلقائية", Toast.LENGTH_SHORT).show();
        } else {
            stopService(intent);
            Toast.makeText(this, "تم تعطيل المزامنة التلقائية", Toast.LENGTH_SHORT).show();
        }
    }
}
