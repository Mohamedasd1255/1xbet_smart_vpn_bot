package com.secure1xbot.data;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.secure1xbot.CrashBotApplication;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import com.secure1xbot.services.WebSocketClient;
import com.secure1xbot.services.WebSocketClient.WebSocketMessageListener;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import androidx.room.Room;
import com.secure1xbot.data.db.AppDatabase;
import com.secure1xbot.data.db.CrashRoundDao;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * نظام جمع البيانات الحية
 * يقوم بجمع وتخزين بيانات الجولات الحية من اللعبة
 */
public class LiveDataCollectionSystem {
    private static final String TAG = "LiveDataCollectionSystem";
    private static final String WEBSOCKET_URL = "ws://your_websocket_server_url"; // TODO: Replace with actual WebSocket server URL
    private static final int MAX_ROUNDS_TO_KEEP = 1000;
    
    private Context context;
    private CrashRoundDao crashRoundDao;
    private AppDatabase db;
    private WebSocketClient webSocketClient;
    private Gson gson;
    private List<DataCollectionListener> listeners;
    
    /**
     * إنشاء نظام جمع البيانات الحية
     * 
     * @param context سياق التطبيق
     */
    public LiveDataCollectionSystem(Context context) {
        this.context = context;
                db = Room.databaseBuilder(context.getApplicationContext(),
                AppDatabase.class, "crash-rounds-db").build();
        crashRoundDao = db.crashRoundDao();
        this.listeners = new ArrayList<>();
        this.gson = new Gson();

        webSocketClient = new WebSocketClient(WEBSOCKET_URL, new WebSocketMessageListener() {
            @Override
            public void onConnect() {
                Log.d(TAG, "WebSocket Connected");
            }

            @Override
            public void onDisconnect() {
                Log.d(TAG, "WebSocket Disconnected");
                // محاولة إعادة الاتصال بعد فترة
                // يمكنك إضافة منطق إعادة الاتصال هنا
            }

            @Override
            public void onMessage(String message) {
                try {
                    CrashRound round = gson.fromJson(message, CrashRound.class);
                    if (round != null) {
                        collectRound(round);
                    }
                } catch (JsonSyntaxException e) {
                    Log.e(TAG, "Error parsing WebSocket message: " + message, e);
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "WebSocket Error: " + error);
            }
        });
        webSocketClient.connect(); // بدء الاتصال عند تهيئة النظام
    }
    
    /**
     * جمع جولة جديدة
     * 
     * @param round الجولة الجديدة
     */
    // هذه الدالة ستُستدعى الآن بواسطة WebSocketClient عند تلقي جولة جديدة
    private void collectRound(CrashRound round) {
        if (round == null) {
            return;
        }
        
        // إضافة الجولة إلى القائمة
                crashRoundDao.insert(round);
        
        // التأكد من عدم تجاوز الحد الأقصى للجولات
                // يمكن إضافة منطق لحذف الجولات القديمة إذا تجاوز العدد الحد الأقصى
        // سيتم حفظ البيانات تلقائيًا بواسطة Room
        // لا حاجة لـ saveData() هنا بعد الآن
        
        // إخطار المستمعين
        notifyListeners(round);
        
        Log.d(TAG, "تم جمع جولة جديدة: " + round);
    }
    
    /**
     * الحصول على قائمة الجولات المجمعة
     * 
     * @return قائمة الجولات المجمعة
     */
    public List<CrashRound> getCollectedRounds() {
                return crashRoundDao.getAll();
    }
    
    /**
     * الحصول على عدد الجولات المجمعة
     * 
     * @return عدد الجولات المجمعة
     */
    public int getCollectedRoundsCount() {
                return crashRoundDao.getCount();
    }
    
    /**
     * الحصول على آخر N جولة
     * 
     * @param count عدد الجولات المطلوبة
     * @return قائمة آخر N جولة
     */
    public List<CrashRound> getLastRounds(int count) {
        int size = Math.min(count, collectedRounds.size());
                return crashRoundDao.getLatest(count);
    }
    
    /**
     * تحميل البيانات المخزنة
     */
    @SuppressWarnings("unchecked")
    // لم تعد هناك حاجة لهذه الدالة بعد الانتقال إلى Room و WebSockets
    // ولكن سنبقي عليها مؤقتًا لتجنب أخطاء البناء
    private void loadStoredData() {
        Log.d(TAG, "loadStoredData: No longer used with Room database.");
    }
        try {
            File file = new File(context.getFilesDir(), DATA_FILE_NAME);
            
            if (!file.exists()) {
                Log.d(TAG, "ملف البيانات غير موجود");
                return;
            }
            
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
                    // لا حاجة لتحميل البيانات من ملف، Room يتولى ذلك
            
            ois.close();
            fis.close();
            
            Log.d(TAG, "تم تحميل " + collectedRounds.size() + " جولة من البيانات المخزنة");
        } catch (Exception e) {
            Log.e(TAG, "فشل تحميل البيانات المخزنة", e);
            collectedRounds = new CopyOnWriteArrayList<>();
        }
    }
    
    /**
     * حفظ البيانات
     */
    // لم تعد هناك حاجة لهذه الدالة بعد الانتقال إلى Room و WebSockets
    // ولكن سنبقي عليها مؤقتًا لتجنب أخطاء البناء
    private void saveData() {
        Log.d(TAG, "saveData: No longer used with Room database.");
    }
        try {
            File file = new File(context.getFilesDir(), DATA_FILE_NAME);
            
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
                    // لا حاجة لحفظ البيانات في ملف، Room يتولى ذلك
            
            oos.close();
            fos.close();
            
            Log.d(TAG, "تم حفظ " + collectedRounds.size() + " جولة في البيانات المخزنة");
        } catch (Exception e) {
            Log.e(TAG, "فشل حفظ البيانات", e);
        }
    }
    
    /**
     * تصدير البيانات
     * 
     * @return نجاح العملية
     */
    public boolean exportData() {
        // يجب تعديل هذه الدالة لتصدير البيانات من Room Database
        try {
            File exportDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CrashBot");
            
            if (!exportDir.exists()) {
                exportDir.mkdirs();
            }
            
            File exportFile = new File(exportDir, "crash_data_export_" + System.currentTimeMillis() + ".dat");
            
            FileOutputStream fos = new FileOutputStream(exportFile);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
                    // لا حاجة لحفظ البيانات في ملف، Room يتولى ذلك
            
            oos.close();
            fos.close();
            
            Log.d(TAG, "تم تصدير البيانات بنجاح إلى: " + exportFile.getAbsolutePath());
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "فشل تصدير البيانات", e);
            return false;
        }
    }
    
    /**
     * استيراد البيانات
     * 
     * @return نجاح العملية
     */
    @SuppressWarnings("unchecked")
    public boolean importData() {
        // يجب تعديل هذه الدالة لاستيراد البيانات إلى Room Database
        try {
            File importDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CrashBot");
            
            if (!importDir.exists() || !importDir.isDirectory()) {
                Log.e(TAG, "مجلد الاستيراد غير موجود");
                return false;
            }
            
            // البحث عن أحدث ملف تصدير
            File[] files = importDir.listFiles((dir, name) -> name.startsWith("crash_data_export_") && name.endsWith(".dat"));
            
            if (files == null || files.length == 0) {
                Log.e(TAG, "لا توجد ملفات استيراد");
                return false;
            }
            
            File latestFile = files[0];
            long latestTime = latestFile.lastModified();
            
            for (File file : files) {
                if (file.lastModified() > latestTime) {
                    latestFile = file;
                    latestTime = file.lastModified();
                }
            }
            
            FileInputStream fis = new FileInputStream(latestFile);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            List<CrashRound> importedRounds = (List<CrashRound>) ois.readObject();
            
            ois.close();
            fis.close();
            
            // دمج البيانات المستوردة مع البيانات الحالية
            for (CrashRound round : importedRounds) {
                if (!collectedRounds.contains(round)) {
                    collectedRounds.add(round);
                }
            }
            
            // ترتيب البيانات حسب الوقت
            collectedRounds.sort((r1, r2) -> Long.compare(r2.getTimestamp(), r1.getTimestamp()));
            
            // التأكد من عدم تجاوز الحد الأقصى للجولات
            while (collectedRounds.size() > MAX_ROUNDS_TO_KEEP) {
                collectedRounds.remove(collectedRounds.size() - 1);
            }
            
            // حفظ البيانات المدمجة
            saveData();
            
            Log.d(TAG, "تم استيراد " + importedRounds.size() + " جولة من: " + latestFile.getAbsolutePath());
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "فشل استيراد البيانات", e);
            return false;
        }
    }
    
    /**
     * إضافة مستمع لجمع البيانات
     * 
     * @param listener المستمع
     */
    public void addListener(DataCollectionListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }
    
    /**
     * إزالة مستمع لجمع البيانات
     * 
     * @param listener المستمع
     */
    public void removeListener(DataCollectionListener listener) {
        listeners.remove(listener);
    }
    
    /**
     * إخطار المستمعين بجولة جديدة
     * 
     * @param round الجولة الجديدة
     */
    private void notifyListeners(CrashRound round) {
        for (DataCollectionListener listener : listeners) {
            listener.onNewRoundCollected(round);
        }
    }
    
    /**
     * واجهة مستمع جمع البيانات
     */
    public interface DataCollectionListener {
        void onNewRoundCollected(CrashRound round);
    }
}
