#!/bin/bash

# Deployment script for 1xBet Crash Bot
set -e

echo "🚀 Starting deployment of 1xBet Crash Bot..."

# Configuration
PROJECT_NAME="secure1xbot"
DOCKER_IMAGE="$PROJECT_NAME:latest"
CONTAINER_NAME="$PROJECT_NAME-container"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    log_info "Prerequisites check passed ✅"
}

# Build Android APK
build_android() {
    log_info "Building Android APK..."
    
    chmod +x ./gradlew
    ./gradlew clean assembleDebug assembleRelease
    
    if [ $? -eq 0 ]; then
        log_info "Android build completed successfully ✅"
    else
        log_error "Android build failed ❌"
        exit 1
    fi
}

# Build Docker images
build_docker() {
    log_info "Building Docker images..."
    
    docker-compose build
    
    if [ $? -eq 0 ]; then
        log_info "Docker build completed successfully ✅"
    else
        log_error "Docker build failed ❌"
        exit 1
    fi
}

# Deploy to cloud
deploy_cloud() {
    local platform=$1
    
    case $platform in
        "aws")
            log_info "Deploying to AWS..."
            aws cloudformation deploy \
                --template-file aws-infrastructure.yml \
                --stack-name $PROJECT_NAME-stack \
                --parameter-overrides EnvironmentName=$PROJECT_NAME \
                --capabilities CAPABILITY_IAM
            ;;
        "gcp")
            log_info "Deploying to Google Cloud Platform..."
            kubectl apply -f gcp-deployment.yml
            ;;
        "azure")
            log_info "Deploying to Azure..."
            az deployment group create \
                --resource-group $PROJECT_NAME-rg \
                --template-file azure-template.json \
                --parameters environmentName=$PROJECT_NAME
            ;;
        "local")
            log_info "Starting local deployment..."
            docker-compose up -d
            ;;
        *)
            log_error "Unknown platform: $platform"
            log_info "Supported platforms: aws, gcp, azure, local"
            exit 1
            ;;
    esac
}

# Health check
health_check() {
    log_info "Performing health check..."
    
    # Wait for services to start
    sleep 30
    
    # Check training server
    if curl -f http://localhost:5000/health > /dev/null 2>&1; then
        log_info "Training server is healthy ✅"
    else
        log_warn "Training server health check failed ⚠️"
    fi
    
    # Check database
    if docker-compose exec postgres pg_isready > /dev/null 2>&1; then
        log_info "Database is healthy ✅"
    else
        log_warn "Database health check failed ⚠️"
    fi
}

# Cleanup function
cleanup() {
    log_info "Cleaning up..."
    docker system prune -f
}

# Main deployment function
main() {
    local platform=${1:-local}
    
    log_info "Deploying $PROJECT_NAME to $platform..."
    
    check_prerequisites
    build_android
    build_docker
    deploy_cloud $platform
    health_check
    cleanup
    
    log_info "🎉 Deployment completed successfully!"
    log_info "📱 APK files are available in: app/build/outputs/apk/"
    
    if [ "$platform" = "local" ]; then
        log_info "🌐 Training server: http://localhost:5000"
        log_info "📊 Database: localhost:5432"
        log_info "🔄 Redis: localhost:6379"
    fi
}

# Script usage
usage() {
    echo "Usage: $0 [platform]"
    echo "Platforms: aws, gcp, azure, local (default)"
    echo ""
    echo "Examples:"
    echo "  $0           # Deploy locally"
    echo "  $0 local     # Deploy locally"
    echo "  $0 aws       # Deploy to AWS"
    echo "  $0 gcp       # Deploy to Google Cloud"
    echo "  $0 azure     # Deploy to Azure"
}

# Handle script arguments
if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
    usage
    exit 0
fi

# Run main function
main $1

